using DescartesApi.Controllers;
using DescartesApi.Models;

namespace DescartesTest;

[TestClass]
public class UnitTestDiff
{
    [TestMethod]
    public void TestGet()
    {
        var diffController = new DescartesApi.Controllers.DiffController();
        var result = diffController.GetAll();
    }

    [TestMethod]
    public void TestPut()
    {
    }
}